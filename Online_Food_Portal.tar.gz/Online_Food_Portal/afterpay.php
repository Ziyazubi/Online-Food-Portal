<?php
session_start();
?>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
</head>
<body >
        <div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            
          </div>
            </li>
             </form>
                
                
            
        </ul>
        
        <center>
        <div class="tp">
                       
                                  Your order is out
                                  <br><br>
                                  Estimated time <b>35</b> Min
                                  <br><br>
                                  
                                 
                                 <?php
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
     $r1=$_SESSION['id'];
                      $result1=pg_query($con,"select * from dboy,cust where cust.dbid=dboy.dbid and cid=$r1");
                        $result2=pg_query($con,"select cname from cust where cid='$r1'");
                        $name = pg_fetch_row($result2);
                   
                  echo"Hello <b>". $name[0] ." </b>";
                  echo"Your order is delevering by <br><br>";
  
                while($row = pg_fetch_row($result1))
                 {  
  echo "Mr ".$row[1]."<br> From ".$row[2]."<br> Contact number ".$row[3]."<br>Bike ".$row[5]."<br>Bike number".$row[4];
                }
                
                
                echo "<br><br>Show this number to your delivery boy <br><br> ".rand()%10000000000;
                                 ?>
                                  
                       
        </div>
        <center>
<br><br><br><br><br><br>        
<footer>
<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Find Us</b>
<p>
    <a href="www.facebook.com"><img src=" fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src=" insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src=" linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src=" twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html> 







