

<html>

<head>
<link rel="stylesheet" type="text/css" href="c.css">
</head>

<body>

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>  
                <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
            
        </ul>

</body>
</html>
<?php                
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                 $result=pg_query($con,"select * from fooditem");
                 
                 
                 echo"<center><form action="."addmycart.php"." ><table border>";
                  echo"<tr><th>"."Image <br/>"."</th><th>"." Food Name "."</th><th>"."Description"."</th><th>"."Price</th></tr>";
                 $name=$_POST['search'];
                 $name=strtolower($name);
                 while($row = pg_fetch_row($result))
                 {
                 $re="qqq".$row[1];
                 $re=strtolower($re);
                 
                 if(strpos($re,$name))
                 {
                      
                 $r=$row[5].".jpg";
                 echo"<tr><td>"."<img src=\"$r\"/>"."</td><td>"." $row[1] "."</td><td>"."$row[3]"."</td><td>"."$row[4]"."</td><td>"."<input type=\"submit\" value=\"ADD TO CART\" name=\"$row[5]\">"."</td></tr>";
                 }
                 }
                 echo"</center></form></table>";
?>

