<?php
$d="hahahaha kya hal hai";         
$d2="ha";       


if(strpos($d,$d2))
echo "found";
else
echo "noyt";
?>

