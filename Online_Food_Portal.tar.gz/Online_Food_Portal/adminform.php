<?php 
session_start();
if(isset($_POST['fa']))
{
        $a=$_POST['f2'];
        $b=$_POST['f3'];
        $c=$_POST['f4'];
        $d=$_POST['f5'];
        $e=$_POST['f6'];
        if($a==""||$b==""||$c==""||$d==""||$e=="")
        {
                echo"Invalid Input!";
                return;
        }      
        else{        
        
        $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
        $f=rand()%100;

       
        pg_query($conn,"insert into fooditem values('$f','$a','$b','$e','$c','$d');");
       
        }
}
else 
if(isset($_POST['dboy']))
{
        $a=$_POST['id'];
        $b=$_POST['dn'];
        $c=$_POST['c'];
        $d=$_POST['dpno'];
        $e=$_POST['bnum'];
        $f=$_POST['bname'];

        if($a==""||$b==""||$c==""||$d==""||$e==""||$f=="")
        {
                echo"Invalid Input!";
                return;
        }      
        else{

        $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
       
        pg_query($conn,"insert into dboy values('$a','$b','$c','$d','$e','$f');");
        }
}
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="c.css">

</head> 
 <body>
 <div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
             
                    <li>
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </li>
                
        </ul>

<center>

<form action="adminform.php" method="POST">


<div class="db"> 
<br>
<br>
   <input type="submit" value="Orders" name="ao"/>
        
                <input type="submit" value="Add Food Item" name="af"/>
        <br/><br/>

                <input type="submit" value="Add Delivery Boy" name="ad"/>

</form>
<?php
        if(isset($_POST['ao']))
        {
                echo "<center>";                
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                 $result=pg_query($con,"select * from history
                 ");
                 
                 
                 echo"<table border>";
                 
                 echo"<tr><th>Id</th><th>Name</th><th>Phone number</th><th>City</th><th>Email</th></tr>";
                
                 while($row = pg_fetch_row($result))
                
                 echo"<tr><td> $row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td></tr>";
                
                 
                 echo"</table>";
        
                echo"</center>";
        }
?>
<?php
        if(isset($_POST['af']))
        {
?>
<form action="adminform.php" method="POST">

<table>

<table height="500px" width="500px">
<br><br>
                                <caption><b>ADD FOOD ITEM</b></caption>
                  
                                <tr>
                                
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;FOOD NAME:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="f2"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;FOOD TYPE:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="f3"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;FOOD PRICE:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="f4"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;INSERT IMAGE:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="f5"/></td>
                                </tr>
                                
                                  <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;DISCRIPTION :</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="f6"/></td>
                                </tr>
                                <tr>
                                <td colspan="6"><br/><br/><center><input type="submit" name="fa" value="ADD_FOOD_ITEM"/></center></td>
                                </tr>
</table>
</form>
</center>
<?php
}
?>
<?php
        if(isset($_POST['ad']))
        {
?>
<form action="adminform.php" method="POST">

<table>

<table height="500px" width="500px">
<br><br>
                               <caption><b>ADD DElIVERY BOY</b></caption>
                              <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;ID:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="id"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;NAME:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="dn"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;CITY:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="c"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;PHONE NUMBER:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="dpno"/></td>
                                </tr>
                                
                                  <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;BIKE NUMBER :</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="bnum"/></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;BIKE NAME :</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="bname"/></td>
                                </tr>
                                
                                <tr>
                                <td colspan="6"><br/><br/><center><input type="submit" name="dboy" value="ADD_DELIVERY_BOY"/></center></td>
                                </tr>
</table>
</form>
</center>
<?php
}
?>
</div>
<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="/exports/TYBG23/PROJECT/TYBG23/fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>

 </body>
 </html>
 

