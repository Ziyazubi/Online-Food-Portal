<?php       
session_start();
         if($_POST['sub']){
         
                $u=$_POST['un'];
                $p=$_POST['up'];
                
               
                $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                
                $r1=pg_query("select * from admin;");
                
                $row1=pg_fetch_row($r1);
      
                        
                if($row1[1]==$u)
                {
                echo "Agaya yahaaaa";
                        if($row1[2]==$p)
                        {
                       $_SESSION['aid']=$row[0];
                         header("location:adminform.php");
                                  
                        }
                        else
                               $error['e_2']="Entered passwod not matching : ";
                
                }
                else
                        $error['e_1']="Entered username not matching : ";
                
          }
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="c.css">

</head> 
 <body background="pexels-photo-616404.png">

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
              <li><a href="pg1.php"><font color="white">Home</font></a></li>
                              
        </ul>

<br><br><br><br><br><br>
<center>
<div id="log">
	
        <form action="adminlogin.php" method="POST">
        <table>
        <tr><td colspan="2"><b>LOGIN</b></td></tr>
        <tr>
        <td>USERNAME</td>
	<td>
	<input type="text" maxlength="20" name="un" /><br/>
		 <p><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
        </td>
        </tr>
        
        <tr>
        <td>PASSWORD</td>
	<td><input type="password" maxlength="8" name="up" /><br>
		 <p><?php if(isset($error['e_2'])) echo $error['e_2'];?></p>
        </td>
	</tr>
	
	<tr>
	<td colspan="2"><input type="submit" name="sub" value="Login"/>
	<input type="reset" name="re" value="Reset"/></td>
        </tr>
        
        </form>
	</table>
</div>
</form>
</center>
<br/><br/><br/><br/><br/><br/><br/><br/>
<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html>
