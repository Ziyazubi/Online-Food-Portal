
<?php 
session_start();

        $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
        $result1=pg_query("select * from fooditem");
        $jpg=".jpg";
        $q=1;
        if(isset($_SESSION['id']))
        {        
        while($row = pg_fetch_row($result1))
        {
        
                if($_POST[$row[5]] == "ADD TO CART")
                {
         
                $result2=pg_query("select * from fooditem where img="."'$row[5]'");
                $r=$_SESSION['id'];
                
                while($row2 = pg_fetch_row($result2))
                {
                
    pg_query($conn,"insert into mycart values('$row[0]','$row[1]','$row[2]','$row[4]','$row[5]','$r','$q');");
                
                }
                }
        
        }
        }
        else{
                /*echo"<center><blink><b><font size=\"20\">"."You need to login"."</font></b></blink></center>";*/
                header("location:login.php");
        }
?>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
</head>
<body>
<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
                
                
            
        </ul>

<div id="below">

        <center>
        <form action="veg.php" method="post">
  
        <?php                
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                 $result=pg_query($con,"select * from fooditem");
                 
                 
                 echo"<table border>";
                  echo"<tr><th>Image <br/></th><th>Food Name </th><th>Description</th><th>Price</th><th>Add to cart</th><tr>";
                
                 while($row = pg_fetch_row($result))
                 {
                 if($row[2]=="veg")
                 {
         
                 $r=$row[5].".jpg";
                 echo"<tr><td>"."<img src=\"$r\"/>"."</td><td>"." $row[1] "."</td><td>"."$row[3]"."</td><td>"."$row[4]"."</td><td>"."<input type=\"submit\" value=\"ADD TO CART\" name=\"$row[5]\">"."</td></tr>";
                 }
                 }
                 echo"</form></table>";

        ?>
        
             </form>
        </center>
</div>


<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="/exports/TYBG23/PROJECT/TYBG23/fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html> 
