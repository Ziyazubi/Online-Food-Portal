<?php 
print_r($_POST);

        $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
        $result=pg_query("select * from mycart");
        
        while($row = pg_fetch_row($result))
        {
        
                if($_POST[$row[0]] == "Remove")
                {
                
                        pg_query("delete from mycart where mfid='$row[0]';");
                        header("location:mycart.php");
                }
        
        }
?>


