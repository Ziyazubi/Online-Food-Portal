drop table payment cascade;
drop table mycart cascade;
drop table fooditem cascade;
drop table admin cascade;
drop table cust cascade;
drop table dboy cascade;

create table dboy(dbid int primary key,dbname varchar(30),dbcity varchar(30),dbphone numeric,bikenum varchar(20),bikename varchar(20));

create table cust(cid int primary key,cname varchar(30),cphno numeric,ccity varchar(30),email varchar(30),password varchar(30),dbid int references dboy(dbid));

create table admin(aid int primary key,aname varchar(20),apass varchar(30));

create table fooditem(fid int primary key,fname varchar(200),ftype varchar(200),fd varchar(500),fprice decimal(13,2),img varchar(100));

create table mycart(mfid int primary key,mfname varchar(200),mftype varchar(200),mfprice decimal(13,2),mimg varchar(100),cid int references cust(cid),q int);

create table payment(pid int primary key,pcardname varchar(20),pcardno int,ptype varchar(20),pcardexpiry date,amount decimal(13,2),cid int references cust(cid));


insert into fooditem values('2','special cup cake','veg','Have A cup cake for happy time','140','cupcake');
insert into fooditem values('3','Chocopie','veg','Have A cup cake for happy time','200','chocopie');
insert into fooditem values('4','Cup cake','veg','A Dish from sonai','220','cupcake2');

insert into fooditem values('5','Dal Bati Choorma','veg','A special dish from rajastan','130','Dal_Bati_Choorma');
insert into fooditem values('6','Gujarati Thali','veg','A special dish from gujrat','120','Gujarati_thali');
insert into fooditem values('7','Kerala Thali','veg','A special dish from Kerla','120','Kerala_thali');

insert into fooditem values('8','prawns Fry','non-veg','A dish for non veg lovers','150','prawns-fry');
insert into fooditem values('9','UP Galouti kabab','non-veg','A dish for non veg lovers','140','UP-Galouti-kabab');
insert into fooditem values('10','Yellow curry with Vegitable','non-veg','A dish for non veg lovers','130','yellow_curry_with_vegitable');

insert into fooditem values('11','prawns biriyani','non-veg','A dish for non veg lovers','80','prawns-biriyani');
insert into fooditem values('12','Butter Chicken','non-veg','A dish for non veg lovers','90','Butter-Chicken');
insert into fooditem values('13','Chicken gravy','non-veg','A dish for non veg lovers','100','chicken-gravy');


insert into fooditem values('14','Hyerabadi chicken biryani','non-veg','A dish for non veg lovers','180','Hyerabadi_chicken_biryani');
insert into fooditem values('15','Kashmir rojan josh','non-veg','A dish for non veg lovers','190','kashmir-rojan-josh');
insert into fooditem values('16','Mutton biryani','non-veg','A dish for non veg lovers','100','mutton-biryanipppu');

insert into fooditem values('17','Burger','breakfast','Start your day with a hevy breakfast','59','burger');
insert into fooditem values('18','Idly','breakfast','Start your day with a hevy breakfast','40','idly');
insert into fooditem values('19','Hrabhara kabab','breakfast','Start your day with a hevy breakfast','60','kabab');

insert into fooditem values('20','Kobi paratha','breakfast','Start your day with a hevy breakfast','40','kobi_paratha');
insert into fooditem values('21','Paratha','breakfast','Start your day with a hevy breakfast','30','paratha');
insert into fooditem values('22','Dosa','breakfast','Start your day with a hevy breakfast','35','dosa');
insert into fooditem values('23','Mendu vada','breakfast','Start your day with a hevy breakfast','35','mendu_vada');

insert into fooditem values('24','kabab','non-veg','A dish for non veg lovers','80','kabab');
insert into fooditem values('25','kashmir-rojan-josh','non-veg','A dish for non veg lovers','90','kashmir-rojan-josh');
insert into fooditem values('26','non-veg','non-veg','A dish for non veg lovers','100','non-veg');

select * from fooditem;

insert into dboy values('1','karthik','pune','3928392838','MH12 8899','Activa');
insert into dboy values('2','Unmya','pune','3928392838','MH12 8432','BMW');
insert into dboy values('3','pranav','pune','3928392838','MH12 2321','Duccati');
insert into dboy values('4','Raja baja','pune','3928392838','MH12 1233','Access 125');
select * from dboy;

insert into cust values('11','Basavraj','1234567891','pune','basu33@gmail.com','Pass1234','2');
select * from cust;
insert into admin values('101','baZira','bazira');

