<?php 
session_start();

        $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
        $result1=pg_query("select * from fooditem");
        $jpg=".jpg";
        $q=1;
        if(isset($_SESSION['id']))
        {        
        while($row = pg_fetch_row($result1))
        {
        
                if($_POST[$row[5]] == "ADD TO CART")
                {
         
                $result2=pg_query("select * from fooditem where img="."'$row[5]'");
                $r=$_SESSION['id'];
                
                while($row2 = pg_fetch_row($result2))
                {
                
    pg_query($conn,"insert into mycart values('$row[0]','$row[1]','$row[2]','$row[4]','$row[5]','$r','$q');");
                
                }
                }
        
        }
        header("location:pg1.php");
        }
        else{
                /*echo"<center><blink><b><font size=\"20\">"."You need to login"."</font></b></blink></center>";*/
                header("location:login.php");
        }
?>


