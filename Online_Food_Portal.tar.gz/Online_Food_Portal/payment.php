<?php
        session_start();

                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");       
        if(isset($_POST['payment']))
        {
        $a=$_POST['t1'];
         $b=$_POST['t2'];
          $c=$_POST['t3'];
           $d=$_POST['t4']; 
           $id=$_SESSION['id'];
           
                   $result1=pg_query("select * from cust where cid='$id';");
       
         if(empty($a) || empty($b) || empty($c) || empty($d))
         {
                $error['e_1']="This field cant be empty";
         }
         else
         {
                $r=$_SESSION['id'];
          
          while($row=pg_fetch_row($result1))
          pg_query($con,"insert into history values('$row[0]','$row[1]','$row[2]','$row[3]','$row[4]');");
   
                          pg_query("delete from mycart where cid='$r';");
                
               
                header("location:afterpay.php");
                
         }
         }
?>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
        <!--<link rel="stylesheet" type="text/css" href="paytable.css">-->
</head>
<body background="pexels-photo-616404.png">
<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
       
             <li><a href="mycart.php"><font color="white">My-cart</font></a></li>            
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a><font color="white">Login</font></a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> <font color="white">Admin</font></a>
                        <a href="login.php"> <font color="white">User</font></a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><font color="white"><?php echo "Hello ".$_SESSION['name'] ?></font></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"><font color="white"> Admin</font></a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a><font color="white">Menu</font></a>
                        <div class="dropdown-content" ><a href="veg.php"> <font color="white">Veg</font></a>
                        <a href="non-veg.php"><font color="white"> Non-Veg</font></a>
                        <a href="breakfast.php"><font color="white"> Breakfast</font></a>
                        <a href="offer.php"><font color="white"> Offers of the day</font></a>
                        </div>
                </li>
               
                <li><a href="about.php"><font color="white">About</font></a></li>
               
                <li><a href="pg1.php"><font color="white">Home</font></a></li>  
            
        </ul>

        <div class="pay">
        <center>
                     <form action="payment.php" method="POST" >
                 
                                       <br/><br/><br/><br/><br/>  
                                                             
                                <table height="500px" width="500px">
                                <caption><b>PAYMENT MANAGEMENT</b></caption>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;NAME OF CARD:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="t1"/>
                                	<p id="i1"><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
                                </td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;CARD NUMBER:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="t2"/>
                                	<p id="i1"><?php if(isset($error['e_1'])) echo $error['e_1'];?></p></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;CARD TYPE:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  name="t3"/>
                                	<p id="i1"><?php if(isset($error['e_1'])) echo $error['e_1'];?></p></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;CARD EXPIRY:</td>
                                <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" name="t4"/>
                                	<p id="i1"><?php if(isset($error['e_1'])) echo $error['e_1'];?></p></td>
                                </tr>
                                <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp;AMOUNT:</td>
     <td colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value="<?php echo $_SESSION['total']?>" name="t5" readonly/></td>
                                </tr>
                                <tr>
                                <td colspan="6"><br/><br/><center><input type="submit" value="Make Payment" name="payment"></input></center></td>
                                </tr>

                       </table>
                       
                       </div>
                     </form>
        <center>
                                  
        <footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html>
