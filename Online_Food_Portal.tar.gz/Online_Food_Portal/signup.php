<?php                
session_start();

        if($_POST['sub']){
                $u=$_POST['user'];
                $pno=$_POST['pno'];
                $c=$_POST['city'];
                $e=$_POST['email'];
                $p1=$_POST['pass1'];
                $p2=$_POST['pass2'];
                
                $vu="/^[a-zA-Z0-9]*$/";
                $p="/^[0-9]{10}$/";
                $c1="/^[a-zA-Z]*$/";
                
                if($p1==$p2)
                {                
                $f=0;
                
                if(!preg_match($vu,$u)){
                $error['e_7']="only letters are allowed"; 
                $f=1;
                }
                
                if(!preg_match($p,$pno)){
                $error['e_2']="Invalid phone number"; 
                $f=1;
                }
                
                if(!preg_match($c1,$c)){
                $error['e_3']="invalid city name "; 
                $f=1;
                }
                
                
                
                if(empty($u)){
                $error['e_1']="Please Enter user name";
                $f=1;
                }
                if(empty($pno)){
                $error['e_2']="Please Enter phone number";
                $f=1;
                }
                if(empty($c)){
                $error['e_3']="Please Enter city";
                $f=1;
                }
                if(empty($e)){
                $error['e_4']="Please Enter email";
                $f=1;
                }
                if(empty($p1)){
                $error['e_5']="Please Enter password here";
                $f=1;
                }
                if(empty($p2)){
                $error['e_6']="Please Enter password here";
                $f=1;
                }
                
                if($f==0){
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                 $num=3;
                 $id=rand()%100;
                 pg_query($con,"insert into cust values('$id','$u','$pno','$c','$e','$p1','$num');");
                
                $_SESSION['id']=$id;
                $_SESSION['name']=$u;
                
                echo $_SESSION['id'];
                                
                header("location:pg1.php");
                }
                }
                else
                {
                        $error['e_8']="Entered password not matching : ";
                }
          }
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="c.css">

</head> 
 <body background="front.jpeg">

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php"> <font color="white">My-cart</font></a></li>
                        
              
                <li><a href="about.php"><font color="white">About</font></a></li>
               
                <li><a href="pg1.php"><font color="white">Home</font></a></li>  
            
        </ul>
</li>
</div>
<br><br>
<center>
<div id="log2">
	<form action="signup.php" method=POST>
	<table>
	
        <tr><td colspan="2">SIGN-UP</td></tr>
        
        <tr>
        
        <td><i>USERNAME</i></td>
        
	        <td>
	        <input type="text" maxlength="20" name="user"/>
	        <p><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
        	<p><?php if(isset($error['e_7'])) echo $error['e_7'];?></p>
	        </td>
	</tr>
	
	<tr>
	<td><i>CONTACT NUMBER</i></td>
        	<td>
        	<input type="numeric" maxlength="10" name="pno" />
        	<p><?php if(isset($error['e_2'])) echo $error['e_2'];?></p>	
        	
	        </td>
	</tr>
	<tr>
	
	<td><i>CITY</i></td>
        	<td><input type="text" name="city" />
        	<p id="i1"><?php if(isset($error['e_3'])) echo $error['e_3'];?></p>
        	</td>
        </tr>
        
        <tr>
	<td><i>EMAIL</i></td>
        	<td><input type="email" name="email"/>
        	<p id="i1"><?php if(isset($error['e_4'])) echo $error['e_4'];?></p>
        	</td>
	</tr>
	
	<tr>
	<td><i>SET PASSWORD</i></td>
        	<td><input type="password" maxlength="8" name="pass1" />
        	<p id="i1"><?php if(isset($error['e_5'])) echo $error['e_5'];?></p>
        	<p id="i1"><?php if(isset($error['e_8'])) echo $error['e_8'];?></p>
        	</td>
        </tr>
        <tr>
        <td><i>CONFIRM PASSWORD</i></td>
        	<td><input type="password" maxlength="8" name="pass2" />
        	<p id="i1"><?php if(isset($error['e_6'])) echo $error['e_6'];?></p>
	        </td>
        </tr>
        <tr>
               	<td colspan="2"><input type="submit" name="sub" value="Login"/>
        	<input type="reset" name="re" value="Reset"/></td>
        </tr>
        </table>
        </form>
</div>
</center><br/><br/><br/><br/><br/><br/><br/><br/>

</body>
</html>
