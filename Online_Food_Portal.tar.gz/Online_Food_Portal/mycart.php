<?php
        session_start();        
         $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
       
        $result1=pg_query($conn,"select * from mycart");
        $val=$_POST['n'];
                
        while($row = pg_fetch_row($result1))
        {
        
                if($_POST[$row[0]] == "ok")
                {
                  pg_query($conn,"update mycart set q='$val' where mfid='$row[0]' ");
       
                  header("location:mycart.php");                
                }
        
        }
        
        
        
        if(isset($_SESSION['id']))
        {
?>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
        <style>
                input{
                        height:50px;
                        width:500px;
                }
        </style>
</head>

<body>

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
                
                
            
        </ul>
<center>

     <?php                
                 $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                 $cid=$_SESSION['id'];
                 
                 $result=pg_query($con," select mfid,mfname,mftype,mfprice,mimg,q from mycart,cust where cust.cid=mycart.cid and mycart.cid='$cid';");
                 
                 $sum=0;
                 echo"<table border>";
                
                 echo"<tr><th>"."Id"."</th><th>"."Img"."</th><th>"."Name"."</th><th>"."type"."</th><th>"."Price"."</th><th>"."Edit"."</th><th>"."Delete"."</th></tr>";
                 $index=0;
       
                 while($row = pg_fetch_row($result))
                 {
                 $index++;
                 $r=$row[4].".jpg";
                  $row[3]=$row[3]*$row[5];               
                 echo"<tr>
                 <td>".$index."</td>
                 <td>"."<img src=\"$r\"/><br/>"."</td>
                 <td>".$row[1]."</td>
                 <td>".$row[2]."</td>
                 <td>".$row[3]."</td>
                 <td>
                 <div class=\"incdec\">
                 <form action=\"mycart.php\" method=\"POST\"> 
                 
                        <input type=\"text\" name=\"n\" value=\" $row[5] \"></input>
                        <input type=\"submit\" name=\"$row[0]\" value=\"ok\"></input>
              
                 </form>
                 </div>
                 </td>
                 
                 <td>"
                 ."<form action=\"removemycart.php\" method=\"POST\"> <div class=\"mydiv\">
                 <input type=\"submit\" name='$row[0]'  value=\"Remove\""."/>
                 </div></form>"."</td>
                 </tr>";
                 
                 $sum=$sum+$row[3];
                 echo"\n";
                  
                 }
                 echo"\n <form action=\"payment.php\" method=\"POST\">";
                 
                 echo"<tr><td colspan=\"4\">"."Total amount"."</td><td>".$sum."</td></tr>";
                 $_SESSION['total']=$sum;
            echo"<tr><td colspan=\"7\">"."<input type=\"submit\" value=\"Check Out\" name=\"pay\">"."</td></tr>";
                 
                 echo"</form></table>";
     ?>
</center>
       <footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html>
<?php
}
else
     /*echo"<center><blink><b><font size=\"20\">"."You need to login"."</font></b></blink></center>";*/
             header("location:login.php");
        

?>
