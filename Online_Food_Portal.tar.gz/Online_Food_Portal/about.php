<?php
session_start();
              
if(isset( $_POST['logout']))
{
        session_destroy();
}
?>

<html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
</head>
<body>
<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
                
                
            
        </ul>
        </nav>
        
        <!--<ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
                </ul>-->
        </br></br></br>
<div>
        <center>
        <img src="maharashtrian_thali.jpeg" height="50%" width="50%" float="left"></center>
      
        
       <center>
 <div class="para">
        <h1><b> ABOUT HOME KITCHEN<b></h1></br>
       
 
 Online food ordering is a process of food delivery or takeout from restaurant or food cooperative through a web page or app.</br> much like ordering conmuer goods online,many of these allow customer to keep accounts with them in order to ordetr to make frequent ording conversient.</br> A customer will search for a favorite restaurent usually filtered via type of culsine and choose from available items .and choose delivery or pick-up payement can be amongst others either by credit card paypal or cash,with the restaurant returning a percentage to the online food company
        </div>
        
        </center>
</div>        
<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html> 
