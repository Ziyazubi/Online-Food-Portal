<?php                
session_start();

        if(isset($_POST['sub']))
        {      

         
                $u=$_POST['un'];
                $p=$_POST['up'];
                
               
                $con=pg_connect("host=192.168.16.1 port=5432 user=TYBG23 dbname=TYBG23") or die ("!Could not open !");
                
                $r1=pg_query("select * from cust;");
                
                while($row1=pg_fetch_row($r1))
                {       
                if($row1[1]==$u)
                {
                        if($row1[5]==$p)
                        {
                        
                        $result=pg_query($con,"select * from cust where password="."'$p'");
                           
                        while($row = pg_fetch_row($result))
                        {
                               $_SESSION['id']=$row[0];
                                 $_SESSION['name']=$row[1];
                               echo $_SESSION['id'];
                        }
                        
                         header("location:pg1.php");
                        }
                        else{
                               $error['e_2']="Entered passwod not matching: ";
                  
                        }
                }
                else{
                        $error['e_1']="Entered username not matching : ";
                }
                }
          }
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="c.css">


</head> 
 <body background="front.jpeg">

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
                      
               
                <li><a href="about.php"><font color="white">About</font></a></li>
               
                <li><a href="pg1.php"><font color="white">Home</font></a></li>
                
       </ul>

	
<!--

    <div class="loginbox">
    <img src="avatar.png" class="avatar">
        <h1>Login Here</h1>
        <form>
            <p>Username</p>
            <input type="text" name="" placeholder="Enter Username">
            <p>Password</p>
            <input type="password" name="" placeholder="Enter Password">
            <input type="submit" name="" value="Login">
            <a href="#">Lost your password?</a><br>
            <a href="#">Don't have an account?</a>
        </form>
        
    </div>

-->

<br><br><br><br><br><br>
<center>
<form action="login.php" method="POST">
<div id="log">

        <table>

        <tr><td colspan="2">LOGIN</td></tr>
        <tr>
        <td>USERNAME</td>
	<td>
	<input type="text" maxlength="20" name="un" /><br/>
		 <p><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
        </td>
        </tr>
        
        <tr>
        <td>PASSWORD</td>
	<td><input type="password" maxlength="20" name="up" /><br>
		 <p><?php if(isset($error['e_2'])) echo $error['e_2'];?></p>
        </td>
	</tr>
	
	<tr>
	<td colspan="2">
	
	<input type="submit" name="sub" value="Login"/>
	<input type="reset" name="re" value="Reset"/><br/><br/>
 
</form>
        
        <form action="forgotpass.php" method="POST">
	<input type="submit" value="Forgot password" name="fp" />
	</form>

	<B>OR</B>

<br/><br/>

	<a href="signup.php">SIGN-UP</a>
        </td>
	</tr>
        </table>

</div>

</center>
<br/><br/><br/><br/><br/><br/><br/><br/>
</body>
</html>
