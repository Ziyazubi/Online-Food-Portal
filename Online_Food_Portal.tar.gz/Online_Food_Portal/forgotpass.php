<?php                
session_start();
echo"hello";
echo $_POST['pass1'];    
echo $_POST['pass2'];           
echo $_POST['pn'];
echo $_POST['em'];
               
         $conn=pg_connect("host=192.168.16.1 port=5432 dbname=TYBG23 user=TYBG23")or die("Could not Connect!");
        $result=pg_query($conn,"select * from cust");
        $f=1;
        
        if(isset($_POST['sub1']))
        { 
        $p1=$_POST['pass1'];    
        $p2=$_POST['pass2'];           
        $pno=$_POST['pn'];
        $email=$_POST['em'];
         
        if($p1 == $p2)
        {       
        while($row = pg_fetch_row($result))
        {
            if($pno == $row[2])
                if($email == $row[4])
                {
         
                pg_query($conn,"update cust set password='$p1' where cid='$row[0]';");
                $f=$f-1;
                header("location:login.php");
                }
                
        }
        }
        else
                $error['e_2']="Passwod not matching ";        
        
        }
        
      if($f==0)
           $error['e_1']="Entered Email and Passwod are not matching: ";
        
?>

<html>
<head>

<link rel="stylesheet" type="text/css" href="c.css">

</head> 
 <body>

<div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                 
          </div>
            </li>
             </form>
                </ul>

<br><br><br><br><br><br>
<center>
<form action="forgotpass.php" method="POST">
<div id="log">
	<b>LOGIN</b><br/><br/><br/><br/>
<br/>
        <center>
        <table border="0.5px solid white" >
	<tr>
	<td>Phone number</td> 
	<td>
	<input type="numeric" maxlength="10" name="pn" placeholder="eg. 9890392080" /><br/>
		 <p><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
        </td>
        </tr>
        <tr>
	<td>Email id</td>
	<td> 
	<input type="email" name="em" placeholder="eg. Examlpe11@gmail.com " /><br><br>
		 <p><?php if(isset($error['e_1'])) echo $error['e_1'];?></p>
        </td>
        </tr>
        <tr>
        <td>New password</td><td><input type="password" name="pass1"/></td>
	</tr>
	
	<tr>
        <td>Confirm password</td><td><input type="password" name="pass2"" /><br><br>
	<p><?php if(isset($error['e_2'])) echo $error['e_2'];?></p></td>
        </tr>
        <tr>

	<td><input type="submit" name="sub1" value="change"/></td>
	<td><input type="reset" name="re1" value="Reset"/></td>
        
        </tr>
        </table>
        </center>
<br/><br/>
</form>
</div>

</center>
<br/><br/><br/><br/><br/><br/><br/><br/>
<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b>Found Us</b>
<p>
    <a href="www.facebook.com"><img src="/exports/TYBG23/PROJECT/TYBG23/fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    <a href="www.linkedin.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
    <a href="www.twitter.com">
    <img src="/exports/TYBG23/PROJECT/TYBG23/twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html>
