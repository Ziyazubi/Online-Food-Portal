<?php
session_start();
              
if(isset( $_POST['logout']))
{
        session_destroy();
}

?><html>
<head>
        <link rel="stylesheet" type="text/css" href="c.css">
</head>
<body onload="currentslide(1)">
       <nav>
        <div class="header">
        <img src="logo.jpg" height="50px" width="50px" />
        <b>
       
        <font size="20px">
        baZIra
        </font>
        </b>     
        </div>
        
        <ul>
            
             <li><a href="mycart.php">My-cart</a></li>
                        
                <?php
                
                if(!isset($_SESSION['id']))
                {
                ?>
                <li class="dropdown"><a>Login</a>
                        <div class="dropdown-content">
                        <a href="adminlogin.php"> Admin</a>
                        <a href="login.php"> User</a>
                        </div>
                </li>
                <?php
                
                }
                else
                {
               
                ?>
                <li class="dropdown"><a><?php echo "Hello ".$_SESSION['name'] ?></a>
                        <div class="dropdown-content">
                        <form action="pg1.php" method="POST">
                        <input type="submit" name="logout" value="logout"/> 
                        </form>
                        </div>
                </li>
                   <li><a href="adminlogin.php"> Admin</a></li>
               <?php
               }
               ?>  
                <li class="dropdown"><a>Menu</a>
                        <div class="dropdown-content" ><a href="veg.php"> Veg</a>
                        <a href="non-veg.php"> Non-Veg</a>
                        <a href="breakfast.php"> Breakfast</a>
                        <a href="offer.php"> Offers of the day</a>
                        </div>
                </li>
               
                <li><a href="about.php">About</a></li>
               
                <li><a href="pg1.php">Home</a></li>
                
             <form action="search.php" method="POST">
            <div class="sin">
            <li><input type="text" placeholder="Search by food name" name="search" /> 
            </div>
            <div class="sim">
            <input type="image" src="search.jpeg" name="search" height="40px" width="40px" padding="10px" value="submit"/> 
          </div>
            </li>
             </form>
                
                
            
        </ul>
        </nav>
        <center> <h1> <b> Welcome to baZIra </b> </h1><br><br> 
        <h2 align="center"><b><blink>Offers of the day</blink></b></h2> </center> 
<div id="below">
        <center>
        <form action="addmycart.php" method="POST">
        <table align="center">
        
        <tr>
            
        <td>
        <img src="cupcake.jpg"/><br/>
        
        <br/><b>Cupcake</b><br/><br>A special dish from sonai<br/><br/><s>200</s> 80/-only <br/><br/><input type="submit" value="ADD TO CART" name="cupcake">
        
        </td>
        
        
        <td>
        <img src="chocopie.jpg"/><br/>
        <br/><b>Chocopie</b><br/>A special dish from kerla<br/><br/><s>180</s> 100/- only<br><br><input type="submit" value="ADD TO CART" name="chocopie"> 
        </td>
        
        <td>
        <img src=" cupcake2.jpg"/><br/>
        <br/><b>CupCake</b><br/>A special dish from kerla<br/><br/><s>180</s> 90/- only<br><br><input type="submit" value="ADD TO CART" name="chocopie"> 
        </td>
        
        </tr>
        
        
        
        
       
        <tr>
        <td>
        <img src=" dosa.jpg"/><br/>
        
        <br/><b>Dosa</b><br/>A special dish from South<br/><br/><s>40</s> 20/-only <br/><br/><input type="submit" value="ADD TO CART" name="dosa">
        </td>
        
        <td>
        <img src=" idly.jpg"/><br/>
        <br/><b>Idly</b><br/>A special dish from Mumbai<br/><br/><s>40</s> 30/-only<br/><br/> <input type="submit" value="ADD TO CART" name="idly"><br/><br/>
        
        </td>
        
        <td>
        <img src=" mendu_vada.jpg"/>
        <br/><b>Mendu vada</b><br/>A special dish from nepal<br/><br/><s>50</s> 30/- only<br><br><input type="submit" value="ADD TO CART" name="mendu_vada"><br/>
                
        </td>
        
        </tr>
        
      
 <tr><td colspan="3">
 ---------------------------------------------------------------------------------------------------------------------------------------------
 </td></tr>
        <tr>
        <td colspan="3">
        <h3 align="center"><b><blink>NON-VEG Special</blink></b></h3> </center> 
        </td>
        </tr>
        
        <tr>    
        <td>
        <img src=" Hyerabadi_chicken_biryani.jpg"/><br/>
        <br/><b>Hyerabadi chicken biryani</b><br/>A special dish from Hyerabad<br/><br/><s>50</s> 30/-only<br><br><input type="submit" value="ADD TO CART" name="Hyerabadi_chicken_biryani"> 
        
        </td>
        
        <td>
        <img src=" kashmir-rojan-josh.jpg"/><br/>
        
        <br/><b>Kashmir rojan josh</b><br/>A special dish from Kashmir<br/><br/><s>50</s> 30/- only<br><br><input type="submit" value="ADD TO CART" name="kashmir-rojan-josh"> 
        
        </td>
        <td>
        
        <img src=" mutton-biryanipppu.jpg"/><br/>
        <br/><b>Mutton Biryani</b><br/>A special dish from India<br/><br/><s>50</s> 30/- only<br><br><input type="submit" value="ADD TO CART" name="mutton-biryanipppu">
      
        </td>
        </tr>
        
        
     
        </tr>
        <td>
        <img src=" kabab.jpg"/><br/>
        <br/><b>Kabab</b><br/>A special dish from North<br/><br/><s>50</s> 30/- only<br><br><input type="submit" value="ADD TO CART" name="kabab">
        </td>
        
        <td>
        <img src="kashmir-rojan-josh.jpg"/><br/>
        <br/><b>kahmir-rojan-josh</b><br/>A special dish from India<br/><br/><s>50</s> 30/- only<br><br><input type="submit" value="ADD TO CART" name="kashmir-rojan-josh">
        </td>
        
        <td>
        <img src=" non-veg.jpg"/><br/>
        <br/><b>Fish</b><br/>A special dish from India<br/><br/><s>50</s> 40/- only<br><br><input type="submit" value="ADD TO CART" name="non-veg"> 
        </td>
        </tr>
       
        </table>
        </form>
        </center>
</div>
<footer>

<div id="right"><b>About kitchen</b>
        <p>
            The prexisting delivery infrastructure<br/>
            of this franchises was well suited for<br/>
            An Online Ordering System, so much so<br/>
            that, in 2018, Bazira announce that it's<br/>
            online sales were growing<br/>
            on average more than 15% each year and <br/>
            near $400 million in 2016 alone.<br/>
        </p>
</div>


<div id="left"><b>Contact Info</b><br/><br/>
<p>
Address:Near Fergusson College<br/><br/>
City:Pune.<br/><br/>
Mobile:(020)-271-704<br/><br/>
Phone:8888988221<br/><br/>
Email:baZIra39@gmail.com<br/><br/>
</p>
</div>

<div id="centerr"><b><center>Find Us</center></b>
<p>
    <a href="www.facebook.com"><img src=" fb.jpeg" height="30px" width="30px" />Facebook</a>
    <br/><br/>
    <a href="www.insta.com">
    <img src=" insta.jpeg" height="30px" width="30px"  />Instagram</a><br/><br/>
    
    <a href="www.linkedin.com">
    <img src=" linkedin.jpeg" height="30px" width="30px"  />Linked.in</a><br/><br/>
     <img src=" twitter.jpeg" height="30px" width="30px"/>Twitter
    </a>
    <br/><br/>
</p>
</div>

</footer>
</body>
</html> 
